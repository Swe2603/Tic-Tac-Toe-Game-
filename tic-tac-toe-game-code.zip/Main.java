
import java.util.*;
class Main{
    public static void main(String[]args){
        char [][] board = new char[3][3]; //creating board
        for(int row=0; row<board.length;row++){
            for(int col=0;col<board[row].length;col++){
                board[row][col] =' '; // initally all are empty
            }
        }
       char player = 'x';   //initally keeping
       boolean gameOver = false; // running the game because it is not Override
       
       Scanner sc = new Scanner(System.in);
       
       while(!gameOver){       //while game not Over
       printBoard(board);      //printing the board
       System.out.print("Player " + player +" enter: "); // entering x or o 
       
       int row = sc.nextInt();  //getting the coordinate of row and col to move the player
       int col = sc.nextInt();
       
       if(board[row][col] == ' '){   // printing only if the coordinate is empty
        board[row][col] = player; //place the element either x or o
        gameOver = hasWon(board , player);  //another function
        
        if(gameOver){   //if gameover printing that palyer
            System.out.println("Player " + player + "has won: ");
        }
        else{   //else switching the current player
            if(player == 'x'){
                player = 'o';
            }
            else{
                player = 'x';
            }
        }
           
       }
       else{
           System.out.println("Invalid move.try again");
       }
       }
       printBoard(board);
    }
    public static boolean hasWon(char[][]board , char player){
        //checking the rows
        for(int row=0;row<board.length;row++){
            if(board[row][0] == player && board[row][1] == player && board[row][2] == player){
                return true;
            }
        }
        
        //checking the columns
        for(int col=0;col<board[0].length;col++){
            if(board[0][col] == player && board[1][col] == player && board[2][col] == player){
                return true;
            }
        }
        
        //checking the diagnol
        if(board[0][0] == player && board[1][1] == player && board[2][2] ==player){
            return true;
        }
        if(board[0][2] == player && board[1][1] == player && board[2][0] == player){
            return true;
        }
        return false;
    }
    public static void printBoard(char[][]board){
        for(int row=0;row<board.length;row++){
            for(int col =0;col<board[row].length;col++){
                System.out.print(board[row][col] + " | ");
            }
            System.out.println();
        }
    }
}